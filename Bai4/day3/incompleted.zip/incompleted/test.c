// #include <stdio.h>

// const int a = 10;

// int func(int x)
// {
//     int func(int x)
//     {
//         x = x + 1;
//         return x;
//     }
//     x--;
//     return func(3);
// }

// int main()
// {
//     int a = 9;
//     printf("%d", a);

//     {
//         int a = 10;
//         printf("%d", a);
//     }

//     return 0;
// }
